from discord_webhook import DiscordWebhook as dw
wh = ""
msg = ""
resp = dw(url=wh, content=msg)
resp.execute()