import re

def bruh(burh) -> str:
	if burh in [True, 1, '1', 'yes', 'y', 'sure']:
		return r"(?<=\\)(?!4|8|0|3|6|5)\d+"
	if burh in [False, 0, '0', 'no', 'n', 'nope']:
		return r"(?<=\\)\d+"

e=0
reg = bruh(e)

decoded_str = str(input("e: "))

print(re.findall(reg, decoded_str))
decimal_list = [x for x in re.findall(reg, decoded_str)]

char_str = "".join([chr(int(x)) for x in decimal_list])

# deserialize the Lua table and access its contents
table_str = f"loadstring({char_str})()"
print(table_str)