import requests
from bs4 import BeautifulSoup
import keyboard

letter = input("Enter a letter: ")

url = f"https://www.dictionary.com/browse/{letter}"

response = requests.get(url)
soup = BeautifulSoup(response.content, "html.parser")

word_links = soup.find_all("a"exit)
print(word_links)
print("Press the 'R' key to start typing or 'T' to cancel.")
def main():
    for link in word_links:
        keyboard.write(link + "*")
        keyboard.press_and_release("enter")
        wait(3.5)

while True:
    if keyboard.is_pressed("r"):
        main()
        break
    elif keyboard.is_pressed("t"):
        print("Typing canceled.")
        exit()

