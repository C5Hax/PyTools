import keyboard as k
import random as r
import string
from time import sleep

def genrand(leng: int) -> str:
    l = 'l' + 'I'
    return ''.join(r.choice(l) for _ in range(leng))

def spam(amnt: int, leng: int) -> None:
    for _ in range(amnt):
        msg = genrand(leng)
        k.write(message)
        k.press('Enter')
        sleep(1.5)

if __name__=='__main__':
    amnt = int(input("Enter spam amount: "))
    leng = int(input("Enter message length: "))
    print("Starting in a few seconds")
    sleep(3)
    spam(amnt,leng)
    input("Press `Enter` to continue. . . ")
