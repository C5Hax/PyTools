import re

input_string = str(input("Enter format: "))
patterns = [
    r'R = (\d+)',
    r'G = (\d+)',
    r'B = (\d+)',
    r'H = (\d+)',
    r'BR = (\d+)',
    r'CN = "([\w\s]+)"',
    r'I = (\d+)',
    r'BL = (\d+)',
    r'X = ([\d\.]+)',
    r'Y = ([\d\.]+)',
    r'Z = ([\d\.]+)',
    r'HEX = "([\w\s]+)"'
]

matches = [re.search(p, input_string) for p in patterns]
values = [m.group(1) for m in matches]
print('\n')
print(values)
output_string = '```\nRed = {}\nGreen = {}\nBlue = {}\nHue = {}\nBrightness = {}\nColor Name = {}\nIntensity = {}\nBlackness = {}\nX = {}\nY = {}\nZ = {}\nHex = {}\n```'.format(*values)
rgb = 'rgb({}, {}, {})'.format(*values)

print(output_string+'\n'+rgb)
input(" ")