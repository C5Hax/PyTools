# Caesar Cipher Encoder & Decoder.

def caesar_cipher(mode, shift, message):
    if mode == "encode":
        encrypted_message = ""
        for letter in message:
            if letter.isalpha():
                shifted_letter = chr((ord(letter.lower()) - 97 + shift) % 26 + 97)
                if letter.isupper():
                    encrypted_message += shifted_letter.upper()
                else:
                    encrypted_message += shifted_letter
            else:
                encrypted_message += letter
        return encrypted_message
    elif mode == "decode":
        decrypted_message = ""
        for letter in message:
            if letter.isalpha():
                shifted_letter = chr((ord(letter.lower()) - 97 - shift) % 26 + 97)
                if letter.isupper():
                    decrypted_message += shifted_letter.upper()
                else:
                    decrypted_message += shifted_letter
            else:
                decrypted_message += letter
        return decrypted_message
    else:
        return "Invalid mode. Please choose either 'encode' or 'decode'."

message = str(input("Enter message: "))

cipher = []
for i in range(25):
    if i == 0: continue
    print(caesar_cipher('decode', i, message))
    cipher.append(caesar_cipher('decode', i, message))
    if (i == 25) or (i == 25-1): continue
    print('')

print(cipher)