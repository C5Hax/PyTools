import subprocess

cmd1 = 'tasklist'
cmd2 = '/FO'
cmd3 = 'csv'
cmd4 = '|'
cmd5 = 'findstr'
cmd6 = 'Rob'

process1 = subprocess.Popen([cmd1, cmd2, cmd3], stdout=subprocess.PIPE)
process2 = subprocess.Popen([cmd5, cmd6], stdin=process1.stdout, stdout=subprocess.PIPE)

output = process2.communicate()[0]
print(output.decode('utf-8'))
