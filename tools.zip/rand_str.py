import string as s
import random as r
from pyperclip import copy as c
def gen(leng) -> str:
	a=s.ascii_lowercase
	b=''
	for _ in range(leng):
		b+=''.join(r.choice(a))
	return b
def main() -> None:
	l=int(input("Enter length: "))
	g=gen(l)
	print(g)
	c(g)
if __name__ == '__main__':
	main()