'''
String generators.
'''
import random
import string

class StringGenerator:
    @staticmethod
    def randstr(length: int) -> str:
        '''
            Generates a string with random letters
        '''
        return ''.join(random.choice(s.ascii_lowercase + s.ascii_uppercase) for _ in range(length))
    
    @staticmethod
    def randlil(length: int) -> str:
        '''
            Generates a string with only 'l' and 'I'
        '''
        return ''.join(random.choice('lI') for _ in range(length))
