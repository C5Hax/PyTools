import random

def generate_math_question(nums, target_sum):
    question = '+'.join(str(num) for num in nums)
    return f'chr({question})'

user_input = input("Enter a string: ")
char_codes = [ord(char) for char in user_input]
questions = []
for char_code in char_codes:
    numbers = []
    if char_code > 0:
        digits = [int(digit) for digit in str(char_code)]
        numbers.extend(digits)
    else:
        numbers.append(char_code)
    target_sum = char_code
    difference = target_sum - sum(numbers)
    numbers.append(difference)
    random.shuffle(numbers)
    question = generate_math_question(numbers, target_sum)
    questions.append(question)
questions_str = '+'.join(questions)
print(questions_str)
