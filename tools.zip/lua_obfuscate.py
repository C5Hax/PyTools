import re
import random as r
from pyperclip import copy

def replacew(inp):
    ptrn=r"\b\w+\b\s*="
    rnd_str=''.join(r.choices(['l','I'],k=10))

    out=re.sub(ptrn,f"{rnd_str} = ",inp)

    vname=re.findall(ptrn,inp)[0].strip("=").strip()
    if vname in out:
        out = out.replace(vname, rnd_str)
    out = out.replace('\n', ';')

    return out


script = """hello='print("Hello, world")'
loadstring(hello)()"""

def getby(scriper):
    garbaerg=[]
    for sus in range(len(scriper)):
        garbaerg.append(ord(scriper[sus]))
    return garbaerg

def conv(whatintheworldisthis):
    bufer=""
    for o in range(len(whatintheworldisthis)):
        bufer +="\\" +str(whatintheworldisthis[o])
    return bufer

def obf(sercipt: str):
    idontknowwhatthehellisthissoignorethisvariablepleaselol = getby(sercipt)
    strn = conv(idontknowwhatthehellisthissoignorethisvariablepleaselol)
    return strn

obfusc = replacew(script)
print(obfusc)
print("loadstring(\""+obf(obfusc)+"\")()")
copy("loadstring(\""+obf(obfusc)+"\")()")
