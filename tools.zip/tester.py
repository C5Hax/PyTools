import time as t

def gettime():
    b = t.localtime()
    return b

gettime()

def parsetime(e: tuple):
    if e == str:
        return 'nil'
    x=[]
    for t in e:
        x.append(t)
    j=[]
    for a in x:
        j.append(str(a))
    date='';date+=j[1];date+='/';date+=j[2];date+='/';date+=j[0];time='';time+=j[3];time+=':';time+=j[4];time+=':';time+=j[5]
    final=[]
    final.append(date)
    final.append(time)
    return final

print(parsetime(gettime()))
