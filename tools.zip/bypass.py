import random as r
import string as s

funny = "㥡磽냹錻ᄧ" + "錻磽㥡㥡냹"
final = ''
final2 = ''
a=s.ascii_lowercase
b=a.upper()
fin=a+b
leng=int(input("LengthWord: "))

for _ in range(leng):
	final+=''.join(r.choice(fin))

for _ in range(leng):
	final2+=''.join(r.choice(funny))

formatte="{{"+f" {final}:{funny[:4]}({final2}) "+"}}"
print(formatte)
input("Press any key to continue . . . ")