import pyautogui
import time
import subprocess

while True:
    # Click on mouse position
    pyautogui.click(x=957, y=441)

    # Wait for specified time
    time.sleep(round(52.84))

    # Prompt for input
    user_input = input("Do you want to continue? (y/n)")

    # Check input
    if user_input == "n":
        # Kill RobloxPlayerBeta.exe process
        subprocess.call(["taskkill", "/f", "/im", "RobloxPlayerBeta.exe"])
        time.sleep(7)
    elif user_input == "y":
        # Exit program
        break
