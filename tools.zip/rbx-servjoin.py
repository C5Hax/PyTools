'''
A script that makes joining a specific server easy.
'''
import pyperclip as p

gameid = int(input("Enter game ID: "))
gamecode = str(input("Enter game UUID: "))

def copystr(string: str) -> None:
	try:
		p.copy(string)
	except Exception as e:
		return 'Error found: '+e

def main() -> None:
	try:
		copystr(f"Roblox.GameLauncher.joinGameInstance({gameid},\"{gamecode}\")")
	except Exception as e:
		raise 'Error found: '+e
	print('\nCopied successfully!')
	input('\nPress enter to continue . . . 	')
if __name__ == '__main__':
	main()
