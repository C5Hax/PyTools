import re
import sys
from pyperclip import copy

args = sys.argv[1:]
fn = sys.argv[:1]

if len(args) < 2:
	print("Error: Insufficient arguments.")
	print(f"Usage: python {fn} <obfuscated_text> <mode>")
	sys.exit(1)

obfuscated_text = ' '.join(args[:-1])
mode = int(args[-1])

reg = r":regional_indicator_([a-z]):"
reg2 = r"([a-zA-Z])"

if mode == 1:
	match = re.findall(reg2, obfuscated_text)
	final = ''
	for char in match:
		final += f":regional_indicator_{char.lower()}: "
	print(final)

elif mode == 2:
	def replace(match):
		char = match.group(1)
		return char.upper() if char.islower() else char.lower()

	deobf = re.sub(reg, replace, obfuscated_text)
	deobf = deobf.lower()

	print(deobf)
	copy(deobf)

else:
	print("Error: Invalid mode.")
	print("Mode must be either 1 (obfuscation) or 2 (deobfuscation).")
