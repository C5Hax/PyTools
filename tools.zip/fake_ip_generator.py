import random as r
import requests as req
from pyperclip import copy as c

ips = []
def main():
	a=r.randint(0,255)
	b=r.randint(0,255)
	c=r.randint(0,255)
	d=r.randint(0,255)
	full=f'{a}.{b}.{c}.{d}'
	return full

if __name__ == '__main__':
	for _ in range(8): ips.append(main()); print(main()); c(str(ips))
