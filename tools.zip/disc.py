import requests
import random
import time

from bs4 import BeautifulSoup

def check(url):
    try:
        response = requests.get(url, allow_redirects=True)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            if soup.find('title').text == 'Discord':
                return True
            else:
                return False
        else:
            return False
    except requests.exceptions.RequestException:
        return False

def rnd_str(length: int):   
    lowerx = "abcdefghijklmnopqrstuvwxyz"
    upperx = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digits = '1234567890'
    finalx = lowerx + upperx + digits
    string = ''
    for _ in range(length):
        string += random.choice(finalx)
    return string

num = 0
mode = input("Enter mode: ")
if mode.lower() == 'true':
    vanity = input("Enter vanity link: ")
    linkers = check("https://discord.gg/" + vanity)
    print(linkers)
    if linkers:
        print(f'Discord invite link verified! https://discord.gg/{vanity} | {linkers}')
    else:
        print('Invalid link!')
elif mode.lower() == 'false':
    try:
        while True:
            link = "https://discord.gg/" + rnd_str(random.choice([7, 8, 10]))
            if check(link):
                print(f'Found invite link! {check(link)} | {link}\n')
            else:
                num += 1
                print(f'No invite link. #{num}')
                continue
            time.sleep(random.randint(1, 4))
    except KeyboardInterrupt:
        print('KeyboardInterrupt, press Enter to continue')
        input('')
