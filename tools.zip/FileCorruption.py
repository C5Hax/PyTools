import os as o
import random as r
import string as s
import colorama as ca
from time import sleep
from colorama import Fore as F
from halo import Halo

ca.init()

blacklisted_char = ['\"',"\'",":",";"]

spinx = Halo(text="'Corrupting' the file..",spinner="dots")
def generate_random(length: int):
    x = ''
    a = s.ascii_lowercase
    b = a.upper()
    c = s.digits
    d = "!#$%*+-.?@\\^_`~"
    f = a+b+c+d

    for _ in range(length):
        x += ''.join(r.choice(f))
    return x


print(f"""{F.RED}
 ______ _ _       _____                            _            
|  ____(_) |     / ____|                          | |           
| |__   _| | ___| |     ___  _ __ _ __ _   _ _ __ | |_ ___ _ __ 
|  __| | | |/ _ \ |    / _ \| '__| '__| | | | '_ \| __/ _ \ '__|
| |    | | |  __/ |___| (_) | |  | |  | |_| | |_) | ||  __/ |   
|_|    |_|_|\___|\_____\___/|_|  |_|   \__,_| .__/ \__\___|_|   
                                            | |                 
                                            |_|
{F.RESET}""")

file: str = str(input("Enter file path: "))
leng: int = int(input("How much to corrupt [255 is recommended]: "))

spinx.start()
with open(file,"w") as f:
    for _ in range(0,leng):
        f.write(f"{generate_random(990)}")
        f.write("\n")

spinx.stop()
sleep(3)

