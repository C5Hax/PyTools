import re
import subprocess as sp

wget = 'winget-list.txt'

with open(wget, 'w') as f:
    sp.call(['winget', 'list'], stdout=f)
    print('List has been written')

with open(wget, 'r') as f:
    output = f.read()
    output = re.sub(r'[…\\/-\|]', '', output)
    output = re.sub(r'\{[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}\}', '', output)

output = re.sub(r'Name\s+Id\s+Version\s+Available\s+Source\n-+\n', '', output)

package_ids = re.findall(r'([A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)', output)
package_names = re.findall(r'^([A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)\s+.*$', output, re.MULTILINE)

valid_packages = [package for package in package_ids if not re.match(r'^\d+(\.\d+)*$', package)]
valid_package_names = [re.sub(r'v?\d+(\.\d+)*', '', name).strip() for name in package_names]

print('Winget Package Verify\n')
for package in valid_packages:
    print(package)
    verify = str(input(f"Verify package? [y/n]: "))
    if verify == 'y':
        print('\n')
        continue
    elif verify == 'n':
        print('Deleting..\n')
        sp.call(['winget','rm',package])
        print('\nDeleted!\n')


