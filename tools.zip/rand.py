import random as r
import string as s
import sys
from pyperclip import copy as co

x=''
a=s.ascii_lowercase
b=a.upper()
c=s.digits
d=a+b+c
e=int(input("Enter length: "))
for _ in range(e):
    x += ''.join(r.choice(d))
co(x)
print(x)
input("Press enter to continue . . . ")
sys.exit(0)
