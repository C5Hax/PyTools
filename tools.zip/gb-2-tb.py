import os
import platform as pf
e: int = int(input("Enter number: "))

def is_file(filename):
	return os.path.exists(filename)

def is_windows():
	if pf.system() == "Windows":
		return True
	if pf.system() != "Windows":
		return False

def humanbytes(B):
	"""
	Return the given bytes as a human friendly KB, MB, GB, or TB string.
	Credits: https://stackoverflow.com/a/31631711
	"""
	B = float(B)
	KB = float(1024)
	MB = float(KB ** 2) # 1,048,576
	GB = float(KB ** 3) # 1,073,741,824
	TB = float(KB ** 4) # 1,099,511,627,776

	if B < KB:
		return '{0} {1}'.format(B,'Bytes' if 0 == B > 1 else 'Byte')
	elif KB <= B < MB:
		return '{0:.2f} KB'.format(B / KB)
	elif MB <= B < GB:
		return '{0:.2f} MB'.format(B / MB)
	elif GB <= B < TB:
		return '{0:.2f} GB'.format(B / GB)
	elif TB <= B:
		return '{0:.2f} TB'.format(B / TB)


if __name__ == "__main__":
	print(f"{e:,} bytes == {humanbytes(e)}")
	if is_file("gb-2-tb.exe") is True:
		if is_windows() is True:
			os.system("gb-2-tb.exe")
			os.system("clear && ./gb-2-tb.exe")
	elif is_file("gb-2-tb.py") is True:
		if is_windows() is True:
			os.system("cls && python gb-2-tb.py")
			os.system("clear && python3 gb-2-tb.py")