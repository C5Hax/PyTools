import requests
from bs4 import BeautifulSoup

lang = str(input("Enter text: "))
lang_final = lang.replace(' ','%20')

url = "https://translate.google.com/?text="+lang_final
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')
span_class = soup.find('span', class_='HwtZe')
language = soup.find('span', class_='VfPpkd-jY41G-V67aGc')
language = str(language).replace('- Detected', '')


print(f"{span_class.text} - {language}")
