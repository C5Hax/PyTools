import re
import os
import requests as req

code = r"""
C:\\Users\\kuda\\bruh
"""

if not code.strip():
	print('Put some output/code..')

def savefile(string, filename):
	with open(filename, 'w') as f:
		f.write(string)

fixed1 = re.sub(r'[a-zA-Z0-9_\-\\]+$', '[USER DIRECTORY]', code)

ip = str(req.get('https://ipecho.net/plain').content)
ipEscaped = re.escape(ip)
print(ipEscaped )
fixed2 = re.sub(ipEscaped, '***.***.***.***', fixed1)

def main() -> None:
	sv = input("Save file? [y/n/yes/no]: ")
	if sv.lower() in ['y', 'yes']:
		try:
			savefile(fixed2, 'saved.txt')
			print('Saved to `saved.txt`')
		except Exception as e:
			print('Error:\n' + str(e))
			exit(1)
	elif sv.lower() in ['n', 'no']:
		print('Code:\n' + fixed2)
	else:
		print('Incorrect mode')

if __name__ == '__main__':
	main()
