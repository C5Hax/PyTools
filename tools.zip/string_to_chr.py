string = str(input("Enter a string: "))
encoded = [f"chr({ord(char)})" for char in string]
encoded_str = "+".join(encoded)

print(encoded_str)
