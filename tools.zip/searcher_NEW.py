import requests
import re
import colorama as ca
from bs4 import BeautifulSoup
from time import sleep
from colorama import Fore as F

ca.init()

blocked_websites = ["roblox.com", "scriptpastebin", "tiktok.com", "fescripts.com", "en.d-jelly.cfd", "vrv.sauna-blockhaus.de"]
linkvertise_count = 0
def get_search_results(query, start):
    url = f"https://www.google.com/search?q={query}&start={start}&tbm=vid"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36"
    }
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")
    search_results = soup.find_all("div", class_="g")
    return search_results

def is_blocked(link):
    for website in blocked_websites:
        if website in link:
            return True
    return False

def save_links(finals):
    with open('links.txt', 'w') as f:
        for link in finals:
            f.write(link + '\n')

query = str(input("enter query: "))
finals = []

# get search results for the first 3 pages
for start in range(0, 30, 10):
    search_results = get_search_results(query, start)
    for result in search_results:
        try:
            link = result.find("a")["href"]
            if is_blocked(link):
                continue
            finals.append(link)
            print(link)
            if "linkvertise" in link:
                print(f"\n{F.YELLOW}WARNING: Linkvertise detected in starting phase.\nUse `https://bypass.vip` to bypass it.{F.RESET}\n")
                linkvertise_count += 1

            uroaid_div = result.find("div", class_="Uroaid")
            if uroaid_div is not None:
                if is_blocked(uroaid_div):
                    continue
                pastebin_links = re.findall("(?P<url>https?://pastebin.com/[^\s]+)", str(uroaid_div))
                for pb in pastebin_links:
                    print(pb)
                    finals.append(pb)

            check = result.find("div", class_="qLRx3b tjvcx GvPZzd cHaqb")
            if check is not None:
                if is_blocked(check):
                    continue
                finals.append(check)
                print(check)
            if "linkvertise" in check:
                print(f"{F.YELLOW}WARNING: Linkvertise detected in phase 2.\nUse `https://bypass.vip` to bypass it.{F.RESET}\n")
                linkvertise_count += 1
            if linkvertise_count <= 0:
                pass
            else:
                print(f"\nLinkvertise links: {linkvertise_count}")
        except:
            pass

save_links(finals)
