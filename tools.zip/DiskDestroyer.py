import sys
import os as o
import colorama as ca
import platform as pf
from colorama import Fore as F
from time import sleep
from halo import Halo

ca.init()

y = 'y'
n = 'n'

o.system('cls')

@Halo(text="Loading functions..",spinner="dots")
def l1():
    sleep(5)
    print("\n✔ FileDestroyer\n")
    sleep(3)
    print("\n✔ DriveFormatter\n")
    sleep(4)

@Halo(text="Checking OS..",spinner="dots")
def l2():
    sleep(4)
    if pf.system() == "Windows":
        print(f"\nOS: {pf.system()}")
        print("Correct OS, continuing\n\n")

@Halo(text="Loading program..",spinner="dots")
def l3():
    sleep(6)
    print('\n')

l1()
l2()
l3()

@Halo(text="Deleting files.. ", spinner="dots")
def filedestroyer(drive_name_or_letter: str):
    o.system(f"del /f /s /q {drive_name_or_letter} > logs.log")
    dir_list = [d for d in o.listdir(drive_name_or_letter) if o.path.isdir(d)]
    for direc in dir_list:
        subdirs = [sd for sd in os.listdir(dir) if os.path.isdir(os.path.join(dir, sd))]

    o.system(f"rmdir /s /q {drive_name_or_letter}")
    print(f"\n{F.BLUE}Finished!{F.RESET}")
    o.system("tree "+drive_name_or_letter)

@Halo(text=f"Formatting drive..", spinner='dots')
def driveformat(file: str):
    o.system(f"format /Q /FS:NTFS /V:DriveFormatter {file}")

def main():
    print(f"""{F.RED}
  ______ _ _      _____            _                             
 |  ____(_) |    |  __ \\          | |                            
 | |__   _| | ___| |  | | ___  ___| |_ _ __ ___  _   _  ___ _ __ 
 |  __| | | |/ _ \\ |  | |/ _ \\/ __| __| '__/ _ \\| | | |/ _ \\ '__|
 | |    | | |  __/ |__| |  __/\\__ \\ |_| | | (_) | |_| |  __/ |   
 |_|    |_|_|\\___|_____/ \\___||___/\\__|_|  \\___/ \\__, |\\___|_|   
                                                  __/ |          
                                                 |___/
{F.RESET}\n""")
    choice: str = str(input("Format drive? [Y/N]: "))
    if choice == y:
        choice2: str = str(input(f"{F.YELLOW}WARN: Are you sure you want to continue? "))
        if choice2 == y:
            print(f'{F.RED}So be it.{F.RESET}')
        elif choice2 == n:
            print('Restarting')
            o.system("python DiskDestroyer.py")
        filex: str = str(input("Enter drive path: "))
        driveformat(filex)
        sys.exit(0)
    else:
        pass
    file: str = str(input("Enter file path: "))
    filedestroyer(file)


if __name__ == "__main__":
    main()

