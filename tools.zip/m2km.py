import tkinter as tk
# from tkinter import ttk
import ttkbootstrap as ttk

def convert():
	mile_input = entry_int.get()
	km_output = mile_input * 1.61
	output_string.set(km_output)

wind = ttk.Window(themename='darkly')
wind.title('Converter')
wind.geometry('300x150')

title_label = ttk.Label(master=wind,text='Miles to kilometers.',font='Calibri 24 bold')
title_label.pack()

input_frame = ttk.Frame(master=wind)
entry_int = tk.IntVar()
entry = ttk.Entry(master=input_frame,textvariable=entry_int)
button = ttk.Button(master=input_frame,text='Convert',command = convert)
entry.pack(side = 'left',padx=4)
button.pack(side = 'left')
input_frame.pack(pady=10)

output_string = tk.StringVar()
output_label = ttk.Label(master=wind,text='Output',font='Calibri 24',textvariable=output_string)
output_label.pack(pady=5)

wind.mainloop()

if __name__ != '__main__':
	exit()
if __name__ == '__main__':
	pass