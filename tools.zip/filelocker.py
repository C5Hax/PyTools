import hashlib
from cryptography.fernet import Fernet


def generate_key():
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)


def load_key():
    return open("secret.key", "rb").read()


def encrypt_file(filename, key):
    with open(filename, "rb") as f:
        data = f.read()
    fernet = Fernet(key)
    encrypted = fernet.encrypt(data)
    with open(filename, "wb") as f:
        f.write(encrypted)


def decrypt_file(filename, key):
    with open(filename, "rb") as f:
        data = f.read()
    fernet = Fernet(key)
    decrypted = fernet.decrypt(data)
    with open(filename, "wb") as f:
        f.write(decrypted)


def lock_file():
    filename = input("Enter the name of the file to lock: ")
    key = input("Enter the code for the file: ").encode()
    hashed_key = hashlib.sha256(key).digest()
    generate_key()
    encrypt_file(filename, hashed_key)
    print(f"{filename} has been locked.")


def unlock_file():
    filename = input("Enter the name of the file to unlock: ")
    key = input("Enter the code for the file: ").encode()
    hashed_key = hashlib.sha256(key).digest()
    load_key()
    decrypt_file(filename, hashed_key)
    print(f"{filename} has been unlocked.")


def main():
    print("FileLocker | By ChatGPT")
    mode = input("Enter mode: 1 for lock, 2 for unlock: ")
    if mode == "1":
        lock_file()
    elif mode == "2":
        unlock_file()
    else:
        print("Invalid mode.")

if __name__ == "__main__":
    main()