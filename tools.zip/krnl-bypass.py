import pyautogui

x=100
y=100
# move the mouse relative to its current position
pyautogui.moveTo(x, y, duration=0.7)

