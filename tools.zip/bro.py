import keyboard as k
from time import sleep as wait

plugins = [
	"BetterRTP",
	"ClearLag",
	"DiscordSRV",
	"EasyKits",
	"Essentials",
	"FastAsyncWorldEdit",
	"ItemEdit",
	"ItemTag",
	"Libs Disguises Free",
	"LoginSecurity",
	"LuckPerms",
	"MultiverseCore",
	"NametagEdit",
	"OpenInv",
	"PlayerKits",
	"PowerRanks",
	"SimpleTpa",
	"SkinsRestorer",
	"StaffChatReloaded",
	"SuperVanish",
	"ViaBackwards",
	"ViaVersion",
	"ViaVersionStatus",
	"WorldGuard"
]
time = 5

for num in range(1,time+1):
	print(f'{num}..')
	wait(1.7)

print('GO!')
for plugin in plugins:
	k.write(plugin)
	wait(1.5)
	k.press_and_release('Enter')
	k.wait(']')
	k.write('\b')
	wait(1.6)