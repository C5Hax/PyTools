import random as r
import string as s
import pyperclip as pc

input_str = 'print(\'get trolled you literal idiot nub hahahahhahahahr nub\')'
fname = 'obf.py'

obfuscate_code = "_OBFUSCATED_BY_[Dev_#5201]_"

def strrandom(length: int):
    x=''
    a=s.ascii_lowercase
    b=a.upper()
    c=s.digits
    e=a+b+c
    for _ in range(length):
        x += ''.join(r.choice(e))
    return x

def obfuscato(inputs: str):
    output=""
    for char in inputs:
        if char == " ":
            output += " "
        else:
            output += obfuscate_code+char
    return output


#\'\'\'{strrandom(1300 - len(input_str))}\'\'\'
output_str = obfuscato(input_str)
final_str = output_str.replace(obfuscate_code,'')
py = False
obfuscated = True
cmd = f"""jx="{input_str}";exec(jx)"""
if obfuscated == False:
    cmd = f"""jx="{final_str}\""""
else:
    cmd = f"""jx="{output_str}";xj=jx.replace('{obfuscate_code}','');exec(xj)"""

pc.copy(cmd)
print(cmd)