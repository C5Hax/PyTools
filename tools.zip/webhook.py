try:
	from discord_webhook import DiscordWebhook as dw
	from discord_webhook import DiscordEmbed as de
except ImportError:
	raise 'type \'pip3 install discord_webhook\' in command line you idiot'
pass

whook = "https://discord.com/api/webhooks/1086387102201172010/W0wzdPrjaP_CkXm6ehcP-Nd1qeECkbV-k2vaiKqDGsbzV5-Z46zlA_sYifiIeHchUjQp"

def msg(webhook: str, msg: str):
	hook = dw(url=webhook,content=msg)
	hook.execute()

def embed(webhook: str, embed_title: str, embed_desc: str, image: str):
	hook = dw(url=webhook)
	embed = de(title=embed_title, description=embed_desc)
	if image != "none":
		embed.set_image(url=image)
	else:
		pass
	hook.add_embed(embed)
	hook.execute()

def main():
	print('''
	webhook controller
	modes:
		1 = simple message
		2 = embed

	''')
	mode = int(input("Enter mode: "))
	if mode == 1:
		print('\n')
		while True:
			meseg = str(input("> "))
			if meseg == "exit()":
				sys.exit(0)
			msg(whook,meseg)
	if mode == 2:
		print('\n')
		while True:
			e_titl = str(input("Title: "))
			e_desc = str(input("Description: "))
			e_imag = str(input("Enter image url: "))
			if e_titl == "exit()":
				sys.exit(0)
			if e_desc == "exit()":
				sys.exit(0)
			if e_imag == "exit()":
				sys.exit(0)
			if e_imag == 'none':
				embed(whook,e_titl,e_desc,'none')
			else:
				embed(whook,e_titl,e_desc,e_imag)
	if mode != 1 or 2:
		print("choose a mode you idiot")

if __name__ == '__main__':
	main()