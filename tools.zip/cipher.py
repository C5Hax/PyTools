# Caesar Cipher Encoder & Decoder.

def caesar_cipher(mode, shift, message):
	if mode == "encode":
		encrypted_message = ""
		for letter in message:
			if letter.isalpha():
				shifted_letter = chr((ord(letter.lower()) - 97 + shift) % 26 + 97)
				if letter.isupper():
					encrypted_message += shifted_letter.upper()
				else:
					encrypted_message += shifted_letter
			else:
				encrypted_message += letter
		return encrypted_message
	elif mode == "decode":
		decrypted_message = ""
		for letter in message:
			if letter.isalpha():
				shifted_letter = chr((ord(letter.lower()) - 97 - shift) % 26 + 97)
				if letter.isupper():
					decrypted_message += shifted_letter.upper()
				else:
					decrypted_message += shifted_letter
			else:
				decrypted_message += letter
		return decrypted_message
	else:
		return 1

mode = input("Enter 'encode' to encrypt or 'decode' to decrypt: ")
shift = int(input("Enter the shift value (integer): "))
message = input("Enter the message: ")

print(caesar_cipher(mode, shift, message))
print('\n')
input("Press enter to continue . . . ")
