import random as r
import keyboard as k
from time import sleep as wait

maxUnicode = 557_056

unicodes = [chr(i) for i in range(36,maxUnicode)]

for _ in range(len(unicodes)):
	

	if k.is_pressed('['):
		break
	k.wait(']')
	k.write('\b')
	wait(1.2)
	k.write(str(rndChar))

print('\nFINISHED')