import random
import requests
import subprocess
import os
import logging
import string as s
from time import sleep


logging.basicConfig(level=logging.INFO)

helpc="""
help - Prints this message to the output

cmd - Starts command prompt (cmd.exe)
rbx - Starts programs needed for roblox
winamp - Starts audio player
rbxutils - Starts roblox utils
miniworld - Starts Mini World
mc - Starts minecraft
wificheck - Checks if wifi is enabled.
random mode1 - Complete random characters.
random mode2 - Only 'l' and 'I'.
os [vm] - Changes the shell to the os you input
lock - Locks the laptop.

exit - Exit K5CMD
"""

COMMAND_LIST = ["helpcmd", "cmd", "rbx", "winamp", "rbxutils", "miniworld", "mc", "wificheck", "random", "os", "lock", "exit"]
WINAMP_PATH = os.path.join(
    "C:", "Program Files (x86)", "Winamp", "winamp.exe"
)
MINIWORLD_PATH = os.path.join(
    os.environ['APPDATA'], "miniworldOverseasgame", "MicroMiniNew.exe"
)

BLOCKED_PROCESSES = ["Task Manager", "Process Hacker", "Resource Monitor"]

def helpcmd(args=('' or None)):
    logging.info(helpc)

def cmd(args=('' or None)):
    subprocess.run(["cmd"])

def winamp(args=('' or None)):
    print(WINAMP_PATH)
    subprocess.run(['start', WINAMP_PATH])

def miniworld(args=('' or None)):
    subprocess.run(['start', MINIWORLD_PATH])

def rbx(args=('' or None)):
    subprocess.run(['start', 'https://roblox.com/home'])
    subprocess.run(['start', 'https://cdn.krnl.place/getkey'])
    subprocess.run(['start', os.environ['USERPROFILE'], 'Documents', 'KRNL', 'krnl', 'krnlss.exe'])

def rbxutils(args=('' or None)):
    subprocess.run([os.path.join(os.environ['USERPROFILE'], 'Desktop', 'RobloxUtils.exe')])

def mc(args=('' or None)):
    subprocess.run([os.path.join(os.environ['USERPROFILE'], 'AppData', 'Roaming', '.minecraft', 'TLauncher.exe')])

def os(args=('' or None)):
    if (args != '') or (args != None):
        os_codename = args
        subprocess.run(['start', 'cmd', '/c', 'wsl', '-d', os_codename])
        return
    os_codename = input("Enter OS codename: ")
    subprocess.run(['start', 'cmd', '/c', 'wsl', '-d', os_codename])

def wificheck(args=('' or None)):
    try:
        response = req.head('https://www.google.com/', allow_redirects=True, timeout=5)
        print(response.status_code == 200)
    except:
        print(False)

def exit(args=('' or None)):
    exit(0)

def random(mode="mode1"):
    x=''
    if mode == 'mode1':
        a=s.ascii_lowercase
        b=a.upper()
        c=a+b
        length: int = int(input("Enter length: "))

        for _ in range(length):
            x += ''.join(r.choice(c))
        print(x)
    elif mode == 'mode2':
        a='l'
        b='I'
        c=a+b
        length: int = int(input("Enter length: "))

        for _ in range(length):
            x = ''.join(r.choice(c))
        print(x)

def lock(args=('' or None)):
    for proc in psutil.process_iter():
        try:
            process_name = proc.name()
            if process_name in BLOCKED_PROCESSES:
                proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess) as e:
            print(f"Error while killing process {process_name}: {e}")
    while True:
        code = input("Enter code: ")
        if (code == '5201') or (code == 5201):
            print('Correct code!\n')
            subprocess.call(['explorer.exe'])
            break
        elif (code != '5201') or (code != 5201):
            print('Incorrect code!\n')
        


def command_interpreter():
    while True:
        command = input("> ")
        components = command.split()

        name = components[0].lower()
        args = components[1:]
        if (name == 'exit'.upper()) or (name == 'exit'):
            return
        found = False
        for c in COMMAND_LIST:
            if name == c.lower():
                exec(c+f"({args})")
                found = True
                break

        if not found:
            print(f"Command '{name}' not found!\n")

print('K5CMD -- Personal use only.\nv2.0.2 - Release\n')
command_interpreter()
subprocess.call(['pause'])